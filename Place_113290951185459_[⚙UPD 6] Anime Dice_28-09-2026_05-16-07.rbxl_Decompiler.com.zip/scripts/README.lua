--[[
		Thank you for using UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

		!! GETHIDDENPROPERTY ISSUES !!
		Your executor's gethiddenproperty couldn't read the types below, so this save might be missing data or have wrong values.
		Please tell your executor's developers about this. Affected types:
				Failed reads: ["Color3uint8","Enum","NetAssetRef"]

		ServerStorage, ServerScriptService and Server Scripts are IMPOSSIBLE to save because of FilteringEnabled.

		If your player cannot spawn into the game, please move the scripts in StarterPlayer somewhere else or delete them. Then run `game:GetService("Players").CharacterAutoLoads = true`.
		And use "Play Here" to start game instead of "Play" to spawn your Character where your Camera currently is.

		If the chat system does not work, please use the explorer and delete everything inside the TextChatService/Chat service(s).
		Or run `game:GetService("Chat"):ClearAllChildren() game:GetService("TextChatService"):ClearAllChildren()`

		If Union and MeshPart collisions don't work, run the script below in the Studio Command Bar:


		local C = game:GetService("CoreGui")
		local D = Enum.CollisionFidelity.Default

		for _, v in game:GetDescendants() do
			if v:IsA("TriangleMeshPart") and not v:IsDescendantOf(C) then
				v.CollisionFidelity = D
			end
		end
		print("Done")

		If you can't move the Camera, run this script in the Studio Command Bar:

		workspace.CurrentCamera.CameraType = Enum.CameraType.Fixed

		Or Destroy the Camera.

		This file was generated with the following settings:
		{"SavePlayerCharacters":false,"CompressionLevel":9,"Callback":false,"ShowStatus":true,"IgnoreDefaultPlayerScripts":true,"NilInstancesFixes":{"Attachments must be parented to a BasePart or another Attachment":null,"BaseWrap":null,"Animator":null,"Attachment":null,"PackageLink":null,"AdPortal":null},"IgnoreList":["CoreGui","CorePackages"],"__DEBUG_MODE":false,"KillAllScripts":false,"DecompileJobless":false,"Binary":true,"Decompile":true,"IgnoreNotArchivable":true,"Object":null,"DecompileIgnore":["Chat","CoreGui","CorePackages"],"IgnoreSpecialProperties":false,"BoostFPS":false,"IsModel":false,"NilInstances":true,"OptionsAliasesInverse":{"RemovePlayerCharacters":"SavePlayerCharacters","DisableCompression":"CompressionMode","noscripts":"Decompile","XML":"Binary","RemovePlayers":"IsolatePlayers"},"RiskyServicesDisabled":{"Reflection":false,"Encoding":false,"UGC":true},"ExtraInstances":[],"OptionsAliases":{"DecompileScripts":"Decompile","timeout":"DecompileTimeout","StatusText":"ShowStatus","SavePlayers":"IsolatePlayers","SavePlayerGui":"IsolateLocalPlayer","FileName":"FilePath","SaveCharacters":"SavePlayerCharacters","SaveNonCreatable":"SaveNotCreatable","IgnoreArchivable":"IgnoreNotArchivable","SaveNilInstances":"NilInstances","Clipboard":"CopyToClipboard","InstancesBlacklist":"IgnoreList","IsolatePlayerGui":"IsolateLocalPlayer","SaveLocalPlayer":"IsolateLocalPlayer","IgnoreDefaultProps":"IgnoreDefaultProperties"},"ReadMe":true,"IsolateStarterPlayer":true,"TreatUnionsAsParts":false,"SharedBinaryStrings":false,"NotCreatableFixes":["","AdvancedDragger","AnimationTrack","Dragger","Player","PlayerGui","PlayerMouse","PlayerMouse","PlayerScripts","ScreenshotHud","StudioData","TextChatMessage","TextSource","TouchTransmitter","Translator"],"DecompileTimeout":10,"IgnoreProperties":[],"AlternativeWritefile":true,"mode":"full","SaveCacheInterval":56320,"IsolateLocalPlayerCharacter":false,"IsolatePlayers":true,"BytecodeTimeout":3,"FilePath":"Place_113290951185459_[⚙️UPD 6] Anime Dice_28-09-2026_05-16-07","CompressionMode":"zstd","Anonymous":false,"ShutdownWhenDone":false,"IgnoreDefaultProperties":true,"IgnorePropertiesOfNotScriptsOnScriptsMode":false,"AvoidFileOverwrite":true,"SaveNotCreatable":false,"IsolateLocalPlayer":false,"SafeMode":false,"AntiIdle":true,"CopyToClipboard":false,"SaveBytecode":false,"scriptcache":true}

		Elapsed time: 11.323608 seconds                          
		Date (UTC): 27 September 2026 22:16:08 PlaceId: 113290951185459 PlaceVersion: 603 Client Version: 2.738.1397 Platform: Android Executor: Delta 1.1.738.1397 arm64
]]